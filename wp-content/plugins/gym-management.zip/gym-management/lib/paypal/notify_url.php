<?php
echo "hello";
exit;
?>